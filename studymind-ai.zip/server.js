// server.js
// StudyMind AI — RAG + Agentic study mentor backend.
// Made by Vinayaka Pullayyagari with ❤️

require('dotenv').config();
const express = require('express');
const multer = require('multer');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const { extractText } = require('./lib/extract');
const store = require('./lib/store');
const { search } = require('./lib/retrieval');
const { askClaude } = require('./lib/claude');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const UPLOAD_DIR = path.join(__dirname, 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const upload = multer({
  dest: UPLOAD_DIR,
  limits: { fileSize: 25 * 1024 * 1024 } // 25MB per file
});

// ---------- Upload & ingest ----------
app.post('/api/upload', upload.array('files', 20), async (req, res) => {
  if (!req.files || !req.files.length) {
    return res.status(400).json({ error: 'No files uploaded' });
  }

  const results = [];
  for (const file of req.files) {
    try {
      const text = await extractText(file.path, file.originalname);
      const { docId, chunkCount } = store.addDocument(file.originalname, file.mimetype, text);
      results.push({ name: file.originalname, docId, chunkCount, status: 'ok' });
    } catch (err) {
      results.push({ name: file.originalname, status: 'failed', error: err.message });
    } finally {
      fs.unlink(file.path, () => {}); // clean up raw upload, we keep only extracted text
    }
  }

  res.json({ results });
});

app.get('/api/documents', (req, res) => {
  res.json({ documents: store.getAllDocuments() });
});

app.delete('/api/documents/:id', (req, res) => {
  store.deleteDocument(req.params.id);
  res.json({ ok: true });
});

// ---------- Chat query (RAG + agentic answer) ----------
app.post('/api/query', async (req, res) => {
  try {
    const { message, history } = req.body;
    if (!message || !message.trim()) {
      return res.status(400).json({ error: 'message is required' });
    }

    const allChunks = store.getAllChunks();
    const topChunks = search(allChunks, message, 6);

    const reply = await askClaude({
      query: message,
      contextChunks: topChunks,
      history: Array.isArray(history) ? history : []
    });

    res.json({
      reply,
      sources: topChunks.map((c) => ({ doc: c.docName, score: Number(c.score.toFixed(2)) }))
    });
  } catch (err) {
    console.error('Query error:', err);
    res.status(500).json({ error: 'Failed to answer query', details: err.message });
  }
});

// ---------- Priority search across all uploaded material ----------
app.post('/api/search', async (req, res) => {
  try {
    const { query } = req.body;
    if (!query || !query.trim()) {
      return res.status(400).json({ error: 'query is required' });
    }

    const allChunks = store.getAllChunks();
    const results = search(allChunks, query, 8);

    let synthesized = null;
    let synthesisError = null;
    if (results.length) {
      try {
        synthesized = await askClaude({ query, contextChunks: results.slice(0, 5), history: [] });
      } catch (err) {
        console.error('Search synthesis failed (returning raw matches anyway):', err.message);
        synthesisError = 'AI summary unavailable right now, but here are the ranked matches from your material.';
      }
    }

    res.json({
      query,
      answer: synthesized,
      synthesisError,
      results: results.map((r) => ({
        doc: r.docName,
        snippet: r.text.slice(0, 300),
        score: Number(r.score.toFixed(2))
      }))
    });
  } catch (err) {
    console.error('Search error:', err);
    res.status(500).json({ error: 'Search failed', details: err.message });
  }
});

app.get('/api/health', (req, res) => {
  res.json({ ok: true, hasApiKey: !!process.env.ANTHROPIC_API_KEY });
});

app.listen(PORT, () => {
  console.log(`StudyMind AI running on port ${PORT}`);
});
